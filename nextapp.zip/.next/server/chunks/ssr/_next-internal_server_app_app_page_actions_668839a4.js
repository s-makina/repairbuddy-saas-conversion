module.exports=[82390,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_app_page_actions_668839a4.js.map