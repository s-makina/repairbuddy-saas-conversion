module.exports=[36312,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_app_%5Btenant%5D_profile_page_actions_3ff8bb54.js.map