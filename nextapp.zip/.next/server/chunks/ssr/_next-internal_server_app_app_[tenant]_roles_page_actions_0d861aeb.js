module.exports=[20661,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_app_%5Btenant%5D_roles_page_actions_0d861aeb.js.map