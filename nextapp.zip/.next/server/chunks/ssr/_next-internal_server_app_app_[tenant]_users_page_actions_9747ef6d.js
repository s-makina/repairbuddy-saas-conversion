module.exports=[86947,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_app_%5Btenant%5D_users_page_actions_9747ef6d.js.map