module.exports=[65216,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_app_%5Btenant%5D_page_actions_45cfdd02.js.map