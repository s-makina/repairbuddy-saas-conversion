module.exports=[22740,(a,b,c)=>{}];

//# sourceMappingURL=ce889_server_app_app_%5Btenant%5D_placeholder_%5B___path%5D_page_actions_bedafb68.js.map