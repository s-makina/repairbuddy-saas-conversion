globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/898cf03d94f59513.js",
    "static/chunks/1627bf2f54f2038d.js",
    "static/chunks/9af25bcb517d01df.js",
    "static/chunks/f7e899cb2e440e35.js",
    "static/chunks/turbopack-4093ea6d18371323.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];