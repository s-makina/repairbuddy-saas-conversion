"use client";

import React from "react";

export default function AdminProfilePage() {
  return (
    <div className="space-y-2">
      <div className="text-sm text-zinc-600">Profile (placeholder)</div>
      <div className="text-sm text-zinc-500">This page will be implemented later.</div>
    </div>
  );
}
